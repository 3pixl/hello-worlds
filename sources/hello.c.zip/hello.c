// hello world example on C language
#include "stdio.h"

int main() {
    printf("Hello World!");
}