// hello world example in C# language
using System;

// the following code works with .NET 5.0 and later
Console.WriteLine("Hello World!");


// the following code works with .NET 5.0 and earlier
namespace HelloWorlds
{
	class Program
    {
        public static void Main(String[] args)
        {
            Console.WriteLine("Hello World");
        }
    }
}