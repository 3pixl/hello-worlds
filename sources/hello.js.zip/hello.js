// hello world example on JavaScript language
console.log("Hello World!"); // output to the DevTools console
document.write("JS says: Hello World"); // output to the page