-- hello world on Lua language
print("Hello World!")