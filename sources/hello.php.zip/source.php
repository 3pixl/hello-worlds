<?php
    // hello world example on PHP language
    echo "Hello World!";
?>