#!/usr/bin/perl
# hello world example on Perl language
use strict;
use warnings;

print "Hello World!\n";