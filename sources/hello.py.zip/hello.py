# hello world example on Python language
print("Hello World!")