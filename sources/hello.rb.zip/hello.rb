# hello world example on Ruby language
puts("Hello World!")