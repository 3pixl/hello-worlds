// hello world example on Rust language

fn main() {
    println!("Hello World");
}